$(document).ready(function(){

});
function Postcomm(postid,userid,el){
    
    let txt = $("#commtxt").val();
if(txt!=""){

    $.post("../../ajax/ajax.php",{commtxt:txt,iduser:userid,postid:postid},function(response){
        let parent=el.parentNode;
        let commented= parent.querySelector('#commented');
        commented.innerHTML=response;
    })

}
}



